﻿/**
 * jQuery jslides 1.1.0
 *
 * http://www.cactussoft.cn
 *
 * Copyright (c) 2009 - 2013 Jerry
 *
 * Dual licensed under the MIT and GPL licenses:
 *   http://www.opensource.org/licenses/mit-license.php
 *   http://www.gnu.org/licenses/gpl.html
 */
$(function(){
	var numpic = $('#slides li').size()-1;
	var nownow = 0;
	var inout = 0;
	var TT = 0;
	var SPEED = 10000;

    // 当前li以外的li不显示
	$('#slides li').eq(0).siblings('li').css({'display':'none'});

    // 小圆点
	var ulstart = '<ul id="pagination">',
		ulcontent = '',
		ulend = '</ul>';
	ADDLI();
	var pagination = $('#pagination li');
	var paginationwidth = $('#pagination').width();
	$('#pagination').css('margin-left',(-paginationwidth/2))
	
	pagination.eq(0).addClass('current')
		
	function ADDLI(){
		//var lilicount = numpic + 1;
		for(var i = 0; i <= numpic; i++){
			ulcontent += '<li>' + '<a href="#">' + (i+1) + '</a>' + '</li>';
		}
		
		$('#slides').after(ulstart + ulcontent + ulend);	
	}

	pagination.on('click',DOTCHANGE)
	
	function DOTCHANGE(){
		
		var changenow = $(this).index();
		
		$('#slides li').eq(nownow).css('z-index','900');
		$('#slides li').eq(changenow).css({'z-index':'800'}).show();
		pagination.eq(changenow).addClass('current').siblings('li').removeClass('current');
		$('#slides li').eq(nownow).fadeOut(400,function(){$('#slides li').eq(changenow).fadeIn(500);});
		nownow = changenow;
	}
	
	pagination.mouseenter(function(){
		inout = 1;
	})
	
	pagination.mouseleave(function(){
		inout = 0;
	})
	
	function GOGO(){

		var NN = nownow+1;

		if( inout == 1 ){
			} else {
			if(nownow < numpic){
			$('#slides li').eq(nownow).css('z-index','900');
			$('#slides li').eq(NN).css({'z-index':'800'}).show();
			pagination.eq(NN).addClass('current').siblings('li').removeClass('current');
			$('#slides li').eq(nownow).fadeOut(400,function(){$('#slides li').eq(NN).fadeIn(500);});
			nownow += 1;

		}else{
			NN = 0;
			$('#slides li').eq(nownow).css('z-index','900');
			$('#slides li').eq(NN).stop(true,true).css({'z-index':'800'}).show();
			$('#slides li').eq(nownow).fadeOut(400,function(){$('#slides li').eq(0).fadeIn(500);});
			pagination.eq(NN).addClass('current').siblings('li').removeClass('current');

			nownow=0;

			}
		}
		TT = setTimeout(GOGO, SPEED);
	}

	TT = setTimeout(GOGO, SPEED);




    var ImageSwiper = function( imgBox, minRange, clickObject, index, length, set_Time_Out ){
	// 添加swipe支持
    //封装的对象接受所有图片的盒元素与触发切换的最小滑动距离作为参数
    this.imgBox = imgBox;
	this.ready_moved = true; //判断每次滑动开始的标记变量
	this.touchX; //触控开始的手指最初落点
	this.minRange = Number(minRange);
	this.bindTouchEvn(); //初始化绑定滑动事件
    this.clickObject = clickObject;
    this.index = index; // 当前"current"的位置
        //alert(this.index);
    this.length = length;
    this.set_Time_Out = set_Time_Out;
    this.swipeLeft = function() {
        if ( this.index == 0 ) {
            this.clickObject.eq(this.length-1).stop(true, true).trigger("click");
            this.index = this.length -1;
        } else {
            this.clickObject.eq(this.index-1).stop(true, true).trigger("click");
            this.index = this.index - 1;
        }
    };
    this.swipeRight = function() {
        if ( this.index == this.length - 1) {
            this.clickObject.eq(0).stop(true, true).trigger("click");
            this.index = 0;
        } else {
            this.clickObject.eq(this.index+1).stop(true, true).trigger("click");
            this.index = this.index + 1;
        }
    };
}

ImageSwiper.prototype.bindTouchEvn = function() {
	this.imgBox.addEventListener('touchstart', this.touchstart.bind(this), false);
	this.imgBox.addEventListener('touchmove', this.touchmove.bind(this), false);
	this.imgBox.addEventListener('touchend', this.touchend.bind(this), false);

}

ImageSwiper.prototype.touchstart = function(e) {
	if (this.ready_moved) {
		var touch = e.touches[0];
		this.touchX = touch.pageX;
		this.ready_moved = false;
	}
}

ImageSwiper.prototype.touchmove = function(e) {


	var minRange = this.minRange;
	var touchX = this.touchX;
	var imgs_count = this.imgs_count;

	if (!this.ready_moved) {

		var release = e.changedTouches[0];
		var releaseAt = release.pageX;
		if ( releaseAt + minRange < touchX ){

			this.ready_moved = true;
            this.swipeLeft();
		    e.preventDefault();
            clearTimeout( this.set_Time_Out);
            this.set_Time_Out = setTimeout(GOGO, SPEED);


		} else if ( releaseAt - minRange > touchX ) {

			this.ready_moved = true;
			this.swipeRight();
			e.preventDefault();
            clearTimeout( this.set_Time_Out);
            this.set_Time_Out = setTimeout(GOGO, SPEED);
		}
	}
}

ImageSwiper.prototype.touchend = function(e) {


	var minRange = this.minRange;
	var TouchX = this.touchX;

	if ( !this.ready_moved ) {
		var release = e.changedTouches[0];
		var releaseAt = release.pageX;
		if ( releaseAt + minRange < touchX ) {

			this.ready_moved = true;
			this.swipeLeft();
			e.preventDefault();
            clearTimeout( this.set_Time_Out);
            this.set_Time_Out = setTimeout(GOGO, SPEED);


		} else if ( releaseAt - minRange > touchX ) {
			this.ready_moved = true;
			this.swipeRight();
			e.preventDefault();
            clearTimeout( this.set_Time_Out);
            this.set_Time_Out = setTimeout(GOGO, SPEED);
		}
	}
}



var length = pagination.length;
var index;

for ( var i = 0; i < length; i++ ) {
    if (pagination.eq(i).hasClass("current")) {
        index = i;
    }
}

var imgs = new ImageSwiper( document.getElementById("slides"), 30, pagination, index, length, TT );

})